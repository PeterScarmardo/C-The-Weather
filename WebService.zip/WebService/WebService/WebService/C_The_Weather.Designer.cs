﻿namespace WebService
{
    partial class C_The_Weather
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.mainTab = new System.Windows.Forms.TabPage();
            this.closeButton = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.zipCodeTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.getWeatherButton = new System.Windows.Forms.Button();
            this.currentTab = new System.Windows.Forms.TabPage();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.conditionsFullNameLabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.visibilityTextBox = new System.Windows.Forms.TextBox();
            this.pressureTextBox = new System.Windows.Forms.TextBox();
            this.precipitationTextBox = new System.Windows.Forms.TextBox();
            this.windTextBox = new System.Windows.Forms.TextBox();
            this.dewPointTextBox = new System.Windows.Forms.TextBox();
            this.feelsLikeTextBox = new System.Windows.Forms.TextBox();
            this.temperatureTextBox = new System.Windows.Forms.TextBox();
            this.forecastTab = new System.Windows.Forms.TabPage();
            this.periodSixLabel = new System.Windows.Forms.Label();
            this.periodFiveLabel = new System.Windows.Forms.Label();
            this.periodFourLabel = new System.Windows.Forms.Label();
            this.periodThreeLabel = new System.Windows.Forms.Label();
            this.periodSixTextBox = new System.Windows.Forms.TextBox();
            this.periodFiveTextBox = new System.Windows.Forms.TextBox();
            this.periodFourTextBox = new System.Windows.Forms.TextBox();
            this.periodThreeTextBox = new System.Windows.Forms.TextBox();
            this.periodTwoLabel = new System.Windows.Forms.Label();
            this.periodTwoTextBox = new System.Windows.Forms.TextBox();
            this.periodOneLabel = new System.Windows.Forms.Label();
            this.periodOneTextBox = new System.Windows.Forms.TextBox();
            this.periodZeroTextBox = new System.Windows.Forms.TextBox();
            this.periodZeroLabel = new System.Windows.Forms.Label();
            this.periodSixPictureBox = new System.Windows.Forms.PictureBox();
            this.periodFivePictureBox = new System.Windows.Forms.PictureBox();
            this.periodFourPictureBox = new System.Windows.Forms.PictureBox();
            this.periodThreePictureBox = new System.Windows.Forms.PictureBox();
            this.periodTwoPictureBox = new System.Windows.Forms.PictureBox();
            this.periodOnePictureBox = new System.Windows.Forms.PictureBox();
            this.periodZeroPictureBox = new System.Windows.Forms.PictureBox();
            this.cityInfoTab = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.localTimeTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.elevationTextBox = new System.Windows.Forms.TextBox();
            this.longitudeTextBox = new System.Windows.Forms.TextBox();
            this.latitudeTextBox = new System.Windows.Forms.TextBox();
            this.countryTextBox = new System.Windows.Forms.TextBox();
            this.stateTextBox = new System.Windows.Forms.TextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.mainTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.currentTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.forecastTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.periodSixPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodFivePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodFourPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodThreePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodTwoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodOnePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodZeroPictureBox)).BeginInit();
            this.cityInfoTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.mainTab);
            this.tabControl1.Controls.Add(this.currentTab);
            this.tabControl1.Controls.Add(this.forecastTab);
            this.tabControl1.Controls.Add(this.cityInfoTab);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(422, 460);
            this.tabControl1.TabIndex = 0;
            // 
            // mainTab
            // 
            this.mainTab.Controls.Add(this.closeButton);
            this.mainTab.Controls.Add(this.pictureBox3);
            this.mainTab.Controls.Add(this.label16);
            this.mainTab.Controls.Add(this.pictureBox1);
            this.mainTab.Controls.Add(this.zipCodeTextBox);
            this.mainTab.Controls.Add(this.label1);
            this.mainTab.Controls.Add(this.getWeatherButton);
            this.mainTab.Location = new System.Drawing.Point(4, 22);
            this.mainTab.Name = "mainTab";
            this.mainTab.Padding = new System.Windows.Forms.Padding(3);
            this.mainTab.Size = new System.Drawing.Size(414, 434);
            this.mainTab.TabIndex = 0;
            this.mainTab.Text = "Main";
            this.mainTab.UseVisualStyleBackColor = true;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(151, 297);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(107, 23);
            this.closeButton.TabIndex = 7;
            this.closeButton.Text = "Close Program";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::WebService.Properties.Resources.C_Logo_2;
            this.pictureBox3.Location = new System.Drawing.Point(6, 31);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(402, 195);
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(168, 323);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Powered By";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WebService.Properties.Resources.Wunderground_Logo;
            this.pictureBox1.Location = new System.Drawing.Point(136, 339);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 89);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // zipCodeTextBox
            // 
            this.zipCodeTextBox.Location = new System.Drawing.Point(151, 242);
            this.zipCodeTextBox.Name = "zipCodeTextBox";
            this.zipCodeTextBox.Size = new System.Drawing.Size(107, 20);
            this.zipCodeTextBox.TabIndex = 3;
            this.zipCodeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.zipCodeTextBox.Leave += new System.EventHandler(this.zipCodeTextBox_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(82, 245);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Zip Code";
            // 
            // getWeatherButton
            // 
            this.getWeatherButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getWeatherButton.Location = new System.Drawing.Point(151, 268);
            this.getWeatherButton.Name = "getWeatherButton";
            this.getWeatherButton.Size = new System.Drawing.Size(107, 23);
            this.getWeatherButton.TabIndex = 0;
            this.getWeatherButton.Text = "Get Weather";
            this.getWeatherButton.UseVisualStyleBackColor = true;
            this.getWeatherButton.Click += new System.EventHandler(this.getWeatherButton_Click);
            // 
            // currentTab
            // 
            this.currentTab.Controls.Add(this.pictureBox4);
            this.currentTab.Controls.Add(this.conditionsFullNameLabel);
            this.currentTab.Controls.Add(this.pictureBox2);
            this.currentTab.Controls.Add(this.label15);
            this.currentTab.Controls.Add(this.label14);
            this.currentTab.Controls.Add(this.label13);
            this.currentTab.Controls.Add(this.label12);
            this.currentTab.Controls.Add(this.label11);
            this.currentTab.Controls.Add(this.label10);
            this.currentTab.Controls.Add(this.label9);
            this.currentTab.Controls.Add(this.visibilityTextBox);
            this.currentTab.Controls.Add(this.pressureTextBox);
            this.currentTab.Controls.Add(this.precipitationTextBox);
            this.currentTab.Controls.Add(this.windTextBox);
            this.currentTab.Controls.Add(this.dewPointTextBox);
            this.currentTab.Controls.Add(this.feelsLikeTextBox);
            this.currentTab.Controls.Add(this.temperatureTextBox);
            this.currentTab.Location = new System.Drawing.Point(4, 22);
            this.currentTab.Name = "currentTab";
            this.currentTab.Padding = new System.Windows.Forms.Padding(3);
            this.currentTab.Size = new System.Drawing.Size(414, 434);
            this.currentTab.TabIndex = 1;
            this.currentTab.Text = "Current Conditions";
            this.currentTab.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::WebService.Properties.Resources.C_Sub_Logo1;
            this.pictureBox4.Location = new System.Drawing.Point(78, 322);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(246, 52);
            this.pictureBox4.TabIndex = 16;
            this.pictureBox4.TabStop = false;
            // 
            // conditionsFullNameLabel
            // 
            this.conditionsFullNameLabel.AutoSize = true;
            this.conditionsFullNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conditionsFullNameLabel.ForeColor = System.Drawing.Color.Blue;
            this.conditionsFullNameLabel.Location = new System.Drawing.Point(118, 36);
            this.conditionsFullNameLabel.Name = "conditionsFullNameLabel";
            this.conditionsFullNameLabel.Size = new System.Drawing.Size(0, 20);
            this.conditionsFullNameLabel.TabIndex = 15;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(226, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(77, 45);
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(93, 251);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 13);
            this.label15.TabIndex = 13;
            this.label15.Text = "Visibility";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(93, 225);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 13);
            this.label14.TabIndex = 12;
            this.label14.Text = "Pressure";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(93, 199);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 13);
            this.label13.TabIndex = 11;
            this.label13.Text = "Precipitation";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(93, 173);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "Wind";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(93, 147);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Dew Point";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(93, 121);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Feels Like";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(93, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Temperature";
            // 
            // visibilityTextBox
            // 
            this.visibilityTextBox.Location = new System.Drawing.Point(203, 248);
            this.visibilityTextBox.Name = "visibilityTextBox";
            this.visibilityTextBox.ReadOnly = true;
            this.visibilityTextBox.Size = new System.Drawing.Size(100, 20);
            this.visibilityTextBox.TabIndex = 6;
            this.visibilityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pressureTextBox
            // 
            this.pressureTextBox.Location = new System.Drawing.Point(203, 222);
            this.pressureTextBox.Name = "pressureTextBox";
            this.pressureTextBox.ReadOnly = true;
            this.pressureTextBox.Size = new System.Drawing.Size(100, 20);
            this.pressureTextBox.TabIndex = 5;
            this.pressureTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // precipitationTextBox
            // 
            this.precipitationTextBox.Location = new System.Drawing.Point(203, 196);
            this.precipitationTextBox.Name = "precipitationTextBox";
            this.precipitationTextBox.ReadOnly = true;
            this.precipitationTextBox.Size = new System.Drawing.Size(100, 20);
            this.precipitationTextBox.TabIndex = 4;
            this.precipitationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // windTextBox
            // 
            this.windTextBox.Location = new System.Drawing.Point(203, 170);
            this.windTextBox.Name = "windTextBox";
            this.windTextBox.ReadOnly = true;
            this.windTextBox.Size = new System.Drawing.Size(100, 20);
            this.windTextBox.TabIndex = 3;
            this.windTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dewPointTextBox
            // 
            this.dewPointTextBox.Location = new System.Drawing.Point(203, 144);
            this.dewPointTextBox.Name = "dewPointTextBox";
            this.dewPointTextBox.ReadOnly = true;
            this.dewPointTextBox.Size = new System.Drawing.Size(100, 20);
            this.dewPointTextBox.TabIndex = 2;
            this.dewPointTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // feelsLikeTextBox
            // 
            this.feelsLikeTextBox.Location = new System.Drawing.Point(203, 118);
            this.feelsLikeTextBox.Name = "feelsLikeTextBox";
            this.feelsLikeTextBox.ReadOnly = true;
            this.feelsLikeTextBox.Size = new System.Drawing.Size(100, 20);
            this.feelsLikeTextBox.TabIndex = 1;
            this.feelsLikeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // temperatureTextBox
            // 
            this.temperatureTextBox.Location = new System.Drawing.Point(203, 92);
            this.temperatureTextBox.Name = "temperatureTextBox";
            this.temperatureTextBox.ReadOnly = true;
            this.temperatureTextBox.Size = new System.Drawing.Size(100, 20);
            this.temperatureTextBox.TabIndex = 0;
            this.temperatureTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // forecastTab
            // 
            this.forecastTab.Controls.Add(this.periodSixLabel);
            this.forecastTab.Controls.Add(this.periodFiveLabel);
            this.forecastTab.Controls.Add(this.periodFourLabel);
            this.forecastTab.Controls.Add(this.periodThreeLabel);
            this.forecastTab.Controls.Add(this.periodSixTextBox);
            this.forecastTab.Controls.Add(this.periodFiveTextBox);
            this.forecastTab.Controls.Add(this.periodFourTextBox);
            this.forecastTab.Controls.Add(this.periodThreeTextBox);
            this.forecastTab.Controls.Add(this.periodTwoLabel);
            this.forecastTab.Controls.Add(this.periodTwoTextBox);
            this.forecastTab.Controls.Add(this.periodOneLabel);
            this.forecastTab.Controls.Add(this.periodOneTextBox);
            this.forecastTab.Controls.Add(this.periodZeroTextBox);
            this.forecastTab.Controls.Add(this.periodZeroLabel);
            this.forecastTab.Controls.Add(this.periodSixPictureBox);
            this.forecastTab.Controls.Add(this.periodFivePictureBox);
            this.forecastTab.Controls.Add(this.periodFourPictureBox);
            this.forecastTab.Controls.Add(this.periodThreePictureBox);
            this.forecastTab.Controls.Add(this.periodTwoPictureBox);
            this.forecastTab.Controls.Add(this.periodOnePictureBox);
            this.forecastTab.Controls.Add(this.periodZeroPictureBox);
            this.forecastTab.Location = new System.Drawing.Point(4, 22);
            this.forecastTab.Name = "forecastTab";
            this.forecastTab.Padding = new System.Windows.Forms.Padding(3);
            this.forecastTab.Size = new System.Drawing.Size(414, 434);
            this.forecastTab.TabIndex = 3;
            this.forecastTab.Text = "Three Day Forecast";
            this.forecastTab.UseVisualStyleBackColor = true;
            // 
            // periodSixLabel
            // 
            this.periodSixLabel.AutoSize = true;
            this.periodSixLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodSixLabel.Location = new System.Drawing.Point(20, 378);
            this.periodSixLabel.Name = "periodSixLabel";
            this.periodSixLabel.Size = new System.Drawing.Size(0, 20);
            this.periodSixLabel.TabIndex = 22;
            // 
            // periodFiveLabel
            // 
            this.periodFiveLabel.AutoSize = true;
            this.periodFiveLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodFiveLabel.Location = new System.Drawing.Point(20, 323);
            this.periodFiveLabel.Name = "periodFiveLabel";
            this.periodFiveLabel.Size = new System.Drawing.Size(0, 20);
            this.periodFiveLabel.TabIndex = 21;
            // 
            // periodFourLabel
            // 
            this.periodFourLabel.AutoSize = true;
            this.periodFourLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodFourLabel.Location = new System.Drawing.Point(20, 267);
            this.periodFourLabel.Name = "periodFourLabel";
            this.periodFourLabel.Size = new System.Drawing.Size(0, 20);
            this.periodFourLabel.TabIndex = 20;
            // 
            // periodThreeLabel
            // 
            this.periodThreeLabel.AutoSize = true;
            this.periodThreeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodThreeLabel.Location = new System.Drawing.Point(20, 210);
            this.periodThreeLabel.Name = "periodThreeLabel";
            this.periodThreeLabel.Size = new System.Drawing.Size(0, 20);
            this.periodThreeLabel.TabIndex = 19;
            // 
            // periodSixTextBox
            // 
            this.periodSixTextBox.Location = new System.Drawing.Point(208, 369);
            this.periodSixTextBox.Multiline = true;
            this.periodSixTextBox.Name = "periodSixTextBox";
            this.periodSixTextBox.ReadOnly = true;
            this.periodSixTextBox.Size = new System.Drawing.Size(200, 40);
            this.periodSixTextBox.TabIndex = 14;
            this.periodSixTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // periodFiveTextBox
            // 
            this.periodFiveTextBox.Location = new System.Drawing.Point(208, 313);
            this.periodFiveTextBox.Multiline = true;
            this.periodFiveTextBox.Name = "periodFiveTextBox";
            this.periodFiveTextBox.ReadOnly = true;
            this.periodFiveTextBox.Size = new System.Drawing.Size(200, 40);
            this.periodFiveTextBox.TabIndex = 13;
            this.periodFiveTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // periodFourTextBox
            // 
            this.periodFourTextBox.Location = new System.Drawing.Point(208, 256);
            this.periodFourTextBox.Multiline = true;
            this.periodFourTextBox.Name = "periodFourTextBox";
            this.periodFourTextBox.ReadOnly = true;
            this.periodFourTextBox.Size = new System.Drawing.Size(200, 40);
            this.periodFourTextBox.TabIndex = 12;
            this.periodFourTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // periodThreeTextBox
            // 
            this.periodThreeTextBox.Location = new System.Drawing.Point(208, 200);
            this.periodThreeTextBox.Multiline = true;
            this.periodThreeTextBox.Name = "periodThreeTextBox";
            this.periodThreeTextBox.ReadOnly = true;
            this.periodThreeTextBox.Size = new System.Drawing.Size(200, 40);
            this.periodThreeTextBox.TabIndex = 11;
            this.periodThreeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // periodTwoLabel
            // 
            this.periodTwoLabel.AutoSize = true;
            this.periodTwoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodTwoLabel.Location = new System.Drawing.Point(20, 151);
            this.periodTwoLabel.Name = "periodTwoLabel";
            this.periodTwoLabel.Size = new System.Drawing.Size(0, 20);
            this.periodTwoLabel.TabIndex = 10;
            // 
            // periodTwoTextBox
            // 
            this.periodTwoTextBox.Location = new System.Drawing.Point(208, 140);
            this.periodTwoTextBox.Multiline = true;
            this.periodTwoTextBox.Name = "periodTwoTextBox";
            this.periodTwoTextBox.ReadOnly = true;
            this.periodTwoTextBox.Size = new System.Drawing.Size(200, 40);
            this.periodTwoTextBox.TabIndex = 9;
            this.periodTwoTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // periodOneLabel
            // 
            this.periodOneLabel.AutoSize = true;
            this.periodOneLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodOneLabel.Location = new System.Drawing.Point(20, 93);
            this.periodOneLabel.Name = "periodOneLabel";
            this.periodOneLabel.Size = new System.Drawing.Size(0, 20);
            this.periodOneLabel.TabIndex = 7;
            // 
            // periodOneTextBox
            // 
            this.periodOneTextBox.Location = new System.Drawing.Point(208, 82);
            this.periodOneTextBox.Multiline = true;
            this.periodOneTextBox.Name = "periodOneTextBox";
            this.periodOneTextBox.ReadOnly = true;
            this.periodOneTextBox.Size = new System.Drawing.Size(200, 40);
            this.periodOneTextBox.TabIndex = 5;
            this.periodOneTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // periodZeroTextBox
            // 
            this.periodZeroTextBox.Location = new System.Drawing.Point(208, 25);
            this.periodZeroTextBox.Multiline = true;
            this.periodZeroTextBox.Name = "periodZeroTextBox";
            this.periodZeroTextBox.ReadOnly = true;
            this.periodZeroTextBox.Size = new System.Drawing.Size(200, 40);
            this.periodZeroTextBox.TabIndex = 4;
            this.periodZeroTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // periodZeroLabel
            // 
            this.periodZeroLabel.AutoSize = true;
            this.periodZeroLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodZeroLabel.Location = new System.Drawing.Point(20, 39);
            this.periodZeroLabel.Name = "periodZeroLabel";
            this.periodZeroLabel.Size = new System.Drawing.Size(0, 20);
            this.periodZeroLabel.TabIndex = 0;
            // 
            // periodSixPictureBox
            // 
            this.periodSixPictureBox.Location = new System.Drawing.Point(142, 369);
            this.periodSixPictureBox.Name = "periodSixPictureBox";
            this.periodSixPictureBox.Size = new System.Drawing.Size(60, 40);
            this.periodSixPictureBox.TabIndex = 18;
            this.periodSixPictureBox.TabStop = false;
            // 
            // periodFivePictureBox
            // 
            this.periodFivePictureBox.Location = new System.Drawing.Point(142, 313);
            this.periodFivePictureBox.Name = "periodFivePictureBox";
            this.periodFivePictureBox.Size = new System.Drawing.Size(60, 40);
            this.periodFivePictureBox.TabIndex = 17;
            this.periodFivePictureBox.TabStop = false;
            // 
            // periodFourPictureBox
            // 
            this.periodFourPictureBox.Location = new System.Drawing.Point(142, 256);
            this.periodFourPictureBox.Name = "periodFourPictureBox";
            this.periodFourPictureBox.Size = new System.Drawing.Size(60, 40);
            this.periodFourPictureBox.TabIndex = 16;
            this.periodFourPictureBox.TabStop = false;
            // 
            // periodThreePictureBox
            // 
            this.periodThreePictureBox.Location = new System.Drawing.Point(142, 200);
            this.periodThreePictureBox.Name = "periodThreePictureBox";
            this.periodThreePictureBox.Size = new System.Drawing.Size(60, 40);
            this.periodThreePictureBox.TabIndex = 15;
            this.periodThreePictureBox.TabStop = false;
            // 
            // periodTwoPictureBox
            // 
            this.periodTwoPictureBox.Location = new System.Drawing.Point(142, 140);
            this.periodTwoPictureBox.Name = "periodTwoPictureBox";
            this.periodTwoPictureBox.Size = new System.Drawing.Size(60, 40);
            this.periodTwoPictureBox.TabIndex = 8;
            this.periodTwoPictureBox.TabStop = false;
            // 
            // periodOnePictureBox
            // 
            this.periodOnePictureBox.Location = new System.Drawing.Point(142, 82);
            this.periodOnePictureBox.Name = "periodOnePictureBox";
            this.periodOnePictureBox.Size = new System.Drawing.Size(60, 40);
            this.periodOnePictureBox.TabIndex = 6;
            this.periodOnePictureBox.TabStop = false;
            // 
            // periodZeroPictureBox
            // 
            this.periodZeroPictureBox.Location = new System.Drawing.Point(142, 25);
            this.periodZeroPictureBox.Name = "periodZeroPictureBox";
            this.periodZeroPictureBox.Size = new System.Drawing.Size(60, 43);
            this.periodZeroPictureBox.TabIndex = 3;
            this.periodZeroPictureBox.TabStop = false;
            // 
            // cityInfoTab
            // 
            this.cityInfoTab.Controls.Add(this.pictureBox5);
            this.cityInfoTab.Controls.Add(this.label8);
            this.cityInfoTab.Controls.Add(this.localTimeTextBox);
            this.cityInfoTab.Controls.Add(this.label7);
            this.cityInfoTab.Controls.Add(this.label6);
            this.cityInfoTab.Controls.Add(this.label5);
            this.cityInfoTab.Controls.Add(this.label4);
            this.cityInfoTab.Controls.Add(this.label3);
            this.cityInfoTab.Controls.Add(this.elevationTextBox);
            this.cityInfoTab.Controls.Add(this.longitudeTextBox);
            this.cityInfoTab.Controls.Add(this.latitudeTextBox);
            this.cityInfoTab.Controls.Add(this.countryTextBox);
            this.cityInfoTab.Controls.Add(this.stateTextBox);
            this.cityInfoTab.Controls.Add(this.cityTextBox);
            this.cityInfoTab.Controls.Add(this.label2);
            this.cityInfoTab.Location = new System.Drawing.Point(4, 22);
            this.cityInfoTab.Name = "cityInfoTab";
            this.cityInfoTab.Size = new System.Drawing.Size(414, 434);
            this.cityInfoTab.TabIndex = 2;
            this.cityInfoTab.Text = "City Information";
            this.cityInfoTab.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(102, 235);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Local Time";
            // 
            // localTimeTextBox
            // 
            this.localTimeTextBox.Location = new System.Drawing.Point(204, 232);
            this.localTimeTextBox.Name = "localTimeTextBox";
            this.localTimeTextBox.ReadOnly = true;
            this.localTimeTextBox.Size = new System.Drawing.Size(100, 20);
            this.localTimeTextBox.TabIndex = 12;
            this.localTimeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(102, 209);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Elevation";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(102, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Longitude";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(102, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Latitude";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(102, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Country";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(102, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "State";
            // 
            // elevationTextBox
            // 
            this.elevationTextBox.Location = new System.Drawing.Point(204, 206);
            this.elevationTextBox.Name = "elevationTextBox";
            this.elevationTextBox.ReadOnly = true;
            this.elevationTextBox.Size = new System.Drawing.Size(100, 20);
            this.elevationTextBox.TabIndex = 6;
            this.elevationTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // longitudeTextBox
            // 
            this.longitudeTextBox.Location = new System.Drawing.Point(204, 178);
            this.longitudeTextBox.Name = "longitudeTextBox";
            this.longitudeTextBox.ReadOnly = true;
            this.longitudeTextBox.Size = new System.Drawing.Size(100, 20);
            this.longitudeTextBox.TabIndex = 5;
            this.longitudeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // latitudeTextBox
            // 
            this.latitudeTextBox.Location = new System.Drawing.Point(204, 151);
            this.latitudeTextBox.Name = "latitudeTextBox";
            this.latitudeTextBox.ReadOnly = true;
            this.latitudeTextBox.Size = new System.Drawing.Size(100, 20);
            this.latitudeTextBox.TabIndex = 4;
            this.latitudeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // countryTextBox
            // 
            this.countryTextBox.Location = new System.Drawing.Point(204, 124);
            this.countryTextBox.Name = "countryTextBox";
            this.countryTextBox.ReadOnly = true;
            this.countryTextBox.Size = new System.Drawing.Size(100, 20);
            this.countryTextBox.TabIndex = 3;
            this.countryTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // stateTextBox
            // 
            this.stateTextBox.Location = new System.Drawing.Point(204, 96);
            this.stateTextBox.Name = "stateTextBox";
            this.stateTextBox.ReadOnly = true;
            this.stateTextBox.Size = new System.Drawing.Size(100, 20);
            this.stateTextBox.TabIndex = 2;
            this.stateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cityTextBox
            // 
            this.cityTextBox.Location = new System.Drawing.Point(204, 70);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.ReadOnly = true;
            this.cityTextBox.Size = new System.Drawing.Size(100, 20);
            this.cityTextBox.TabIndex = 1;
            this.cityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(102, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "City";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::WebService.Properties.Resources.C_Sub_Logo2;
            this.pictureBox5.Location = new System.Drawing.Point(80, 316);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(246, 48);
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            // 
            // C_The_Weather
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 485);
            this.Controls.Add(this.tabControl1);
            this.Name = "C_The_Weather";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.mainTab.ResumeLayout(false);
            this.mainTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.currentTab.ResumeLayout(false);
            this.currentTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.forecastTab.ResumeLayout(false);
            this.forecastTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.periodSixPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodFivePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodFourPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodThreePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodTwoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodOnePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.periodZeroPictureBox)).EndInit();
            this.cityInfoTab.ResumeLayout(false);
            this.cityInfoTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage mainTab;
        private System.Windows.Forms.TabPage currentTab;
        private System.Windows.Forms.TextBox zipCodeTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button getWeatherButton;
        private System.Windows.Forms.TabPage cityInfoTab;
        private System.Windows.Forms.TextBox longitudeTextBox;
        private System.Windows.Forms.TextBox latitudeTextBox;
        private System.Windows.Forms.TextBox countryTextBox;
        private System.Windows.Forms.TextBox stateTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox elevationTextBox;
        private System.Windows.Forms.TextBox temperatureTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox localTimeTextBox;
        private System.Windows.Forms.TextBox visibilityTextBox;
        private System.Windows.Forms.TextBox pressureTextBox;
        private System.Windows.Forms.TextBox precipitationTextBox;
        private System.Windows.Forms.TextBox windTextBox;
        private System.Windows.Forms.TextBox dewPointTextBox;
        private System.Windows.Forms.TextBox feelsLikeTextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.TabPage forecastTab;
        private System.Windows.Forms.PictureBox periodZeroPictureBox;
        private System.Windows.Forms.Label periodZeroLabel;
        private System.Windows.Forms.TextBox periodZeroTextBox;
        private System.Windows.Forms.Label periodSixLabel;
        private System.Windows.Forms.Label periodFiveLabel;
        private System.Windows.Forms.Label periodFourLabel;
        private System.Windows.Forms.Label periodThreeLabel;
        private System.Windows.Forms.PictureBox periodSixPictureBox;
        private System.Windows.Forms.PictureBox periodFivePictureBox;
        private System.Windows.Forms.PictureBox periodFourPictureBox;
        private System.Windows.Forms.PictureBox periodThreePictureBox;
        private System.Windows.Forms.TextBox periodSixTextBox;
        private System.Windows.Forms.TextBox periodFiveTextBox;
        private System.Windows.Forms.TextBox periodFourTextBox;
        private System.Windows.Forms.TextBox periodThreeTextBox;
        private System.Windows.Forms.Label periodTwoLabel;
        private System.Windows.Forms.TextBox periodTwoTextBox;
        private System.Windows.Forms.PictureBox periodTwoPictureBox;
        private System.Windows.Forms.Label periodOneLabel;
        private System.Windows.Forms.PictureBox periodOnePictureBox;
        private System.Windows.Forms.TextBox periodOneTextBox;
        private System.Windows.Forms.Label conditionsFullNameLabel;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}

